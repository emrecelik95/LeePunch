Lidgren.Network is needed for MasterServer solution.
https://github.com/lidgren/lidgren-network-gen3