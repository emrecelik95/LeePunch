﻿using System;
using System.Threading;
using MSCommon;

namespace MasterServerP2P
{
	public class Program
	{
        static void Main(string[] args)
		{
            int masterPort = CommonConstants.DefaultMasterServerPort; // IMPORTANT // Default : 47856
            if (args.Length > 1)
            {
                try {
                    masterPort = int.Parse(args[1]);
                }
                catch (Exception) {}
            }
            MasterServer masterServer = new MasterServer(masterPort);
            masterServer.Start();

            Console.WriteLine("Masterserver started, Port : " + masterPort); 
			Console.WriteLine("Press ESC to quit");

            while (true)
			{
                try
                {
                    if (Console.KeyAvailable && Console.ReadKey().Key == ConsoleKey.Escape)
                        break;
                }catch (Exception e)
                {
                    Console.WriteLine("Console Exception Caught ::: " + e.Message);
                }
                masterServer.ReadIncomings();
                Thread.Sleep(25);
			}

			masterServer.Shutdown();
            Thread.Sleep(100);
		}
    }
}
