﻿using System.Net;

namespace MasterServerP2P
{
    public struct HostInfo
    {
        /// <summary>
        /// Internal end point for host.
        /// </summary>
        public IPEndPoint internalHostIP;

        /// <summary>
                                             /// Internal end point for host.
                                             /// </summary>
        public IPEndPoint externalHostIP;

        /// <summary>
        /// External end point just for messaging with MS.
        /// </summary>
        public IPEndPoint externalMsgIP;

        public string password;

        public HostInfo(IPEndPoint internalHostIP, IPEndPoint externalHostIP, IPEndPoint externalMsgIP, string password = "")
        {
            this.internalHostIP = internalHostIP;
            this.externalHostIP = externalHostIP;
            this.externalMsgIP= externalMsgIP;
            this.password = password;
        }
    }
}
