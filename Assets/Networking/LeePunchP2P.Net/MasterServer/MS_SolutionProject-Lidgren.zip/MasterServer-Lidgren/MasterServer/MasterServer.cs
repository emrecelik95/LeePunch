﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading;
using Lidgren.Network;
using MSCommon;

namespace MasterServerP2P
{
    class MasterServer
    {
        /// <summary>
        /// Max number of hosts.
        /// </summary>
        private const int MAX_ID = 99999;
        /// <summary>
        /// The timeout to destroy hostInfo.
        /// </summary>
        private const int hostTimeout = 360;
        private NetPeerConfiguration config;

        public Dictionary<int, HostInfo> registeredHosts = new Dictionary<int, HostInfo>(MAX_ID);
        public Queue<KeyValuePair<int, float>> hostQueue = new Queue<KeyValuePair<int, float>>(MAX_ID);
        public NetPeer server { get; private set; }

        public MasterServer(int port = 47856)
        {
            config = new NetPeerConfiguration("MasterServer");
            config.SetMessageTypeEnabled(NetIncomingMessageType.UnconnectedData, true);
            config.Port = port;
        }

        public MasterServer(NetPeerConfiguration config)
        {
            this.config = config;
        }

        public void Start()
        {
            server = new NetPeer(config);
            server.Start();
        }

        public void Shutdown()
        {
            server.Shutdown("Shutting Down");
        }

        public void ReadIncomings()
        {
            NetIncomingMessage msg;
            NetOutgoingMessage response;
            try
            {
                while ((msg = server.ReadMessage()) != null)
                {

                    switch (msg.MessageType)
                    {
                        // We've received a message from a client or a host
                        case NetIncomingMessageType.UnconnectedData:
                            // by design, the first byte always indicates action
                            switch ((MasterServerMessageType)msg.ReadByte())
                            {
                                case MasterServerMessageType.RequestExternalEP:
                                    {
                                        bool sendSomeone = msg.ReadBoolean();
                                        IPEndPoint targetEP = null;
                                        if (sendSomeone)
                                            targetEP = msg.ReadIPEndPoint();
                                        else
                                            targetEP = msg.SenderEndPoint;

                                        NetOutgoingMessage res = server.CreateMessage();
                                        res.Write((byte)MasterServerMessageType.RequestExternalEP);
                                        res.Write(msg.SenderEndPoint);

                                        server.SendUnconnectedMessage(res, targetEP);
                                        break;
                                    }
                                case MasterServerMessageType.RegisterHost:
                                    {
                                        int randID = GetUniqueID();
                                        string password = msg.ReadString();
                                        IPEndPoint internalHostEndPoint = msg.ReadIPEndPoint(); // internal nat punch host end point
                                        IPEndPoint externalHostEndPoint = msg.ReadIPEndPoint(); // external nat punch host end point

                                        IPEndPoint externalMsgEndPoint = msg.SenderEndPoint; ;  // external  end point for messaging with MS

                                        Console.WriteLine("Response Type : " + MasterServerMessageType.RegisterHost.ToString()
                                                        + " \n::: Got registration for host :::"
                                                        + " \n id : " + randID
                                                        + " \n internal host : " + internalHostEndPoint
                                                        + " \n external host (sender) : " + externalHostEndPoint
                                                        + " \n password : " + (String.IsNullOrEmpty(password) ? "(no)" : password + "\n"
                                                        + " \n\n external Msg EP(sender) : " + externalMsgEndPoint));

                                        registeredHosts[randID] = new HostInfo(internalHostEndPoint, externalHostEndPoint, externalMsgEndPoint, password);
                                        hostQueue.Enqueue(new KeyValuePair<int, float>(randID, (float)NetTime.Now));

                                        response = server.CreateMessage();
                                        response.Write((byte)MasterServerMessageType.RegisterHost); // opcode
                                        response.Write(randID);

                                        server.SendUnconnectedMessage(response, externalMsgEndPoint);
                                        break;
                                    }
                                case MasterServerMessageType.RequestHost:
                                    {
                                        int hostID = msg.ReadInt32();
                                        if (!registeredHosts.ContainsKey(hostID))
                                        {
                                            Console.WriteLine("Client requested introduction to nonlisted host! , id : " + hostID + " , "
                                                             + "sender : " + msg.SenderEndPoint);
                                            break;
                                        }
                                        string pw = msg.ReadString();
                                        HostInfo host = registeredHosts[hostID];

                                        if (!pw.Equals(host.password))
                                            break;

                                        Console.WriteLine("Response Type : " + MasterServerMessageType.RequestHost.ToString()
                                                        + "\n ::: Sending info :::\n hostID : " + hostID + " \n internal host : " + host.internalHostIP
                                                        + "\n external host : " + host.externalHostIP
                                                        + "\n password : " + (String.IsNullOrEmpty(host.password) ? "(no)" : host.password
                                                        + "\n\n ::: client (sender) : " + msg.SenderEndPoint));

                                        response = server.CreateMessage();
                                        response.Write((byte)MasterServerMessageType.RequestHost); // opcode
                                        response.Write(host.internalHostIP);
                                        response.Write(host.externalHostIP);

                                        server.SendUnconnectedMessage(response, msg.SenderEndPoint);
                                        break;
                                    }
                                case MasterServerMessageType.RequestNatHolePunch:
                                    {
                                        int hostID = msg.ReadInt32();
                                        if (!registeredHosts.ContainsKey(hostID))
                                        {
                                            Console.WriteLine("Client requested introduction to nonlisted host! , id : " + hostID + " , "
                                                             + "sender : " + msg.SenderEndPoint);
                                            break;
                                        }
                                        HostInfo host = registeredHosts[hostID];
                                        string pw = msg.ReadString();
                                        string token = msg.ReadString();

                                        if (!host.password.Equals(pw))
                                            break;

                                        IPEndPoint clientInternal = msg.ReadIPEndPoint();
                                        IPEndPoint clientExternal = msg.ReadIPEndPoint();

                                        IPEndPoint clientMsgExternal = msg.SenderEndPoint;

                                        Console.WriteLine(msg.SenderEndPoint + " Nat Hole Punch introduction to " + hostID + " (token " + token + ")");

                                        Console.WriteLine("Sending nat hole introduction...");
                                        NatHoleIntroduce(host.internalHostIP, host.externalHostIP, host.externalMsgIP,
                                                            clientInternal, clientExternal, clientMsgExternal, token);
                                        break;

                                    }
                            }
                            break;

                        case NetIncomingMessageType.DebugMessage:
                        case NetIncomingMessageType.VerboseDebugMessage:
                        case NetIncomingMessageType.WarningMessage:
                        case NetIncomingMessageType.ErrorMessage:
                            // print diagnostics message
                            Console.WriteLine(msg.ReadString());
                            break;
                    }

                }
                UpdateHosts();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception : " + e.ToString());
            }
        }

        public int GetUniqueID()
        {
            Random rand = new Random();
            int id = rand.Next(MAX_ID);
            while (registeredHosts.ContainsKey(id))
            {
                Thread.Sleep(1);
                id = rand.Next(MAX_ID);
            }

            return id;
        }

        /// <summary>
        /// Removes unnecessary hosts.
        /// </summary>
        public void UpdateHosts()
        {
            while (hostQueue.Count > 0)
            {
                var kv = hostQueue.Peek();
                if (NetTime.Now - kv.Value < hostTimeout)
                {
                    return;
                }

                var host = hostQueue.Dequeue();
                registeredHosts.Remove(host.Key);
            }
        }

        public void NatHoleIntroduce(IPEndPoint hostInternal, IPEndPoint hostExternal, IPEndPoint hostMsgExternal,
                                     IPEndPoint clientInternal, IPEndPoint clientExternal, IPEndPoint clientMsgExternal, string token)
        {
            NetOutgoingMessage hostMsg = server.CreateMessage();
            hostMsg.Write((byte)MasterServerMessageType.RequestNatHolePunch);
            hostMsg.Write(clientInternal);
            hostMsg.Write(clientExternal);
            hostMsg.Write(token);

            server.SendUnconnectedMessage(hostMsg, hostMsgExternal);

            NetOutgoingMessage clientMsg = server.CreateMessage();
            clientMsg.Write((byte)MasterServerMessageType.RequestNatHolePunch);
            clientMsg.Write(hostInternal);
            clientMsg.Write(hostExternal);
            clientMsg.Write(token);

            server.SendUnconnectedMessage(clientMsg, clientMsgExternal);
        }
    }
}
